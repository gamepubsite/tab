import tkinter as tk
from tkinter import ttk
import win32gui
import win32con
import sys
import win32process
import threading
import time
from elevate import elevate
import shutil
import os
from tkinter import messagebox

class TabLocker:
    def __init__(self):
        elevate(show_console=False)
        self.root = tk.Tk()
        self.root.title("Tab Controller")
        self.root.geometry("200x200")
        self.root.attributes('-topmost', True)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        self.is_locked = False
        self.lock_thread = threading.Thread(target=self.check_windows, daemon=True)
        
        # Create all buttons
        self.status_label = ttk.Label(self.root, text="Lock: Off")
        self.status_label.pack(pady=10)
        
        self.toggle_button = ttk.Button(self.root, text="Toggle", command=self.toggle_lock)
        self.toggle_button.pack(pady=5)
        
        self.close_all_button = ttk.Button(self.root, text="Close Tabs", command=self.close_all_windows)
        self.close_all_button.pack(pady=5)
        
        self.download_button = ttk.Button(self.root, text="Download", command=self.install_permanently)
        self.download_button.pack(pady=5)
        
        self.lock_thread.start()

    def install_permanently(self):
        if getattr(sys, 'frozen', False):
            current_exe = sys.executable
        else:
            current_exe = sys.argv[0]
            
        install_dir = os.path.join(os.getenv('PROGRAMFILES'), 'TabLocker')
        os.makedirs(install_dir, exist_ok=True)
        
        destination = os.path.join(install_dir, 'TabLocker.exe')
        startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
        startup_dest = os.path.join(startup_folder, 'TabLocker.exe')
        
        # Copy to both locations
        shutil.copy2(current_exe, destination)
        shutil.copy2(current_exe, startup_dest)
        
        # Create desktop shortcut
        desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
        shortcut_path = os.path.join(desktop, 'TabLocker.lnk')
        
        ps_script = f'''
        $WshShell = New-Object -comObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
        $Shortcut.TargetPath = "{destination}"
        $Shortcut.Save()
        '''
        
        os.system(f'powershell -command "{ps_script}"')
        messagebox.showinfo("Success", "TabLocker has been installed!\nYou can find it on your desktop.")
    
    def close_all_windows(self):
        def window_enum_handler(hwnd, ctx):
            if win32gui.IsWindowVisible(hwnd):
                if win32gui.GetClassName(hwnd) == "Shell_TrayWnd":
                    return
                if win32gui.GetClassName(hwnd) == "Progman":
                    return
                if win32gui.GetClassName(hwnd) == "WorkerW":
                    return
                
                window_pid = win32process.GetWindowThreadProcessId(hwnd)[1]
                if window_pid != current_pid:
                    title = win32gui.GetWindowText(hwnd)
                    if title and title != "Program Manager":
                        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
        
        current_pid = win32process.GetWindowThreadProcessId(self.root.winfo_id())[1]
        win32gui.EnumWindows(window_enum_handler, None)
        
    def toggle_lock(self):
        self.is_locked = not self.is_locked
        self.status_label.config(text=f"Lock: {'On' if self.is_locked else 'Off'}")
    
    def on_close(self):
        if not self.is_locked:
            self.root.destroy()
            sys.exit()
    
    def check_windows(self):
        while True:
            if self.is_locked:
                current_pid = win32process.GetWindowThreadProcessId(self.root.winfo_id())[1]
                def window_enum_handler(hwnd, ctx):
                    if win32gui.IsWindowVisible(hwnd):
                        if win32gui.GetClassName(hwnd) == "Shell_TrayWnd":
                            return
                        if win32gui.GetClassName(hwnd) == "Progman":
                            return
                        if win32gui.GetClassName(hwnd) == "WorkerW":
                            return
                            
                        window_pid = win32process.GetWindowThreadProcessId(hwnd)[1]
                        if window_pid != current_pid:
                            title = win32gui.GetWindowText(hwnd)
                            if title and title != "Program Manager":
                                win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                                win32gui.CloseWindow(hwnd)
                
                win32gui.EnumWindows(window_enum_handler, None)
            time.sleep(0.1)
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = TabLocker()
    app.run()
